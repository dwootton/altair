"""Altair schema wrappers"""
# flake8: noqa
from .v5.schema import *
